## Thrifty CloudFront Benchmark

Thrifty developers keep a careful eye on the price class of CloudFront distribution resources to reduce your delivery prices by excluding Amazon CloudFront’s more expensive edge locations from your Amazon CloudFront distribution.
