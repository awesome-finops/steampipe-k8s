## Thrifty Network Benchmark

Thrifty developers ensure that they delete unused network resources. This benchmark focuses on finding resources that are not attached (and therefore not in use).
