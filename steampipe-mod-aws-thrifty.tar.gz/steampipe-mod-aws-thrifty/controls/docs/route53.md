## Thrifty Route 53 Benchmark

Thrifty developers keep a careful eye on the actual usage of Route 53 service. This Route 53 benchmark currently checks unused hosted zones, unnecessary health checks and unhealthy resolver endpoints.
