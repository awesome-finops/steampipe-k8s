## Thrifty EMR Benchmark

Thrifty developers ensure that their EMR clusters use the latest generation of Amazon Elastic MapReduce instances instead of the previous generation of instances for better hardware performance, and also ensure that the clusters are not idle for more than 30 minutes.
