## Thrifty CloudTrail Benchmark

Thrifty developers know that multiple active CloudTrail Trails can add significant costs. Be thrifty and eliminate redundant trails.
