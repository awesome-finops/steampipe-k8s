## Thrifty Secrets Manager Benchmark

Thrifty developers ensure their secrets manager's secret is in use. This Secrets Manager Benchmark currently checks if your secrets manager secret is in use.

## Variables

| Variable | Description | Default |
| - | - | - |
| secretsmanager_secret_last_used | The default number of days secrets manager secrets to be considered in-use. | 90 days |